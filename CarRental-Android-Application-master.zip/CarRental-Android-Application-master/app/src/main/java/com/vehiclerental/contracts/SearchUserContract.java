/**
 * CarRental
 *
 * This file provides a light communication object representing the parameters for the search user action
 */

package com.vehiclerental.contracts;

public class SearchUserContract {
    public String searchTerm;
}
